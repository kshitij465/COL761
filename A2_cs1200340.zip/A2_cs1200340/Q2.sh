#!/bin/bash

filename="$1"
resultpath="$2"

python3 main.py "$filename" "$resultpath"
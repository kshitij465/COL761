#!/bin/bash

git clone https://github.com/kshitij465/COL761.git

module load apps/anaconda/3
